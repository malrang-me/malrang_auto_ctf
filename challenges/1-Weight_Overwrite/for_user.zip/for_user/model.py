import torch
import torch.nn as nn
import torch.nn.functional as F

S = 2.0

class CBR(nn.Module):
    def __init__(self, ci, co, k, s=1, p=0, g=1):
        super().__init__()
        self.conv = nn.Conv2d(ci, co, k, stride=s, padding=p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(co)
        self.relu = nn.ReLU6(inplace=True)
    def forward(self, x): return self.relu(self.bn(self.conv(x)))

class DSC(nn.Module):
    def __init__(self, ci, co, s=1):
        super().__init__()
        self.dw = CBR(ci, ci, 3, s=s, p=1, g=ci)
        self.pw = CBR(ci, co, 1)
    def forward(self, x): return self.pw(self.dw(x))

class TanhLinear(nn.Module):
    def __init__(self, ci, co, scale=S):
        super().__init__()
        self.linear = nn.Linear(ci, co)
        self.scale = scale
    def forward(self, x):
        return F.linear(x, torch.tanh(self.linear.weight) * self.scale, self.linear.bias)

class MobileNetMNIST(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv0 = CBR(1, 16, 3, s=1, p=1)
        self.dsc1 = DSC(16, 32, s=1)
        self.dsc2 = DSC(32, 64, s=2)
        self.dsc3 = DSC(64, 64, s=1)
        self.dsc4 = DSC(64, 128, s=2)
        self.dsc5 = DSC(128, 128, s=1)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Sequential()
        self.fc1.linear = nn.Linear(128, 64)
        self.fc1.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Sequential()
        self.fc2.tw = TanhLinear(64, 10, scale=S)

    def forward(self, x):
        x = self.conv0(x)
        for l in [self.dsc1, self.dsc2, self.dsc3, self.dsc4, self.dsc5]:
            x = l(x)
        x = self.pool(x).view(x.size(0), -1)
        x = self.fc1.relu(self.fc1.linear(x))
        return self.fc2.tw(x)
