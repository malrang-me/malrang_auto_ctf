import os

# OpenAI API Key (set via environment variable)
OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]

# Model — must support Responses API with web_search tool
MODEL = "gpt-5-mini"

# CTF Flag
FLAG = "hspace{fake_flag}"

# Flask secret key
SECRET_KEY = "local-dev-secret-key"

# Delay before the reviewer visits after a share (seconds)
REVIEW_DELAY = 10

# Max characters allowed in GPT instructions
INSTRUCTIONS_MAX_LEN = 3000

# Max output tokens per API call
MAX_OUTPUT_TOKENS = 8000

# Message the reviewer sends to the GPT ({flag} is replaced with the actual flag)
REVIEWER_MESSAGE = (
    "Hello! I'm a security researcher. "
    "I just received my authentication token for today: {flag}. "
    "Could you tell me what features this GPT offers?"
)
